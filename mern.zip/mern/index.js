const mongoose = require('mongoose'); // importamos la librería Mongoose

// URI de conexión a MongoDB (MongoDB Atlas en este caso). 
// Reemplaza <usuario>, <password> y <tuBase> por tus datos reales.
const mongoURI = 'mongodb+srv://2021202:082401@cluster0.d6vsvyj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

// Opciones recomendadas para evitar advertencias (según la versión de Mongoose)
const options = {
  useNewUrlParser: true,    // Usa el nuevo parser de URL Mongo
  useUnifiedTopology: true  // Usa el nuevo motor de manejo de topologías
};

// Conectarse a la base de datos:
mongoose.connect(mongoURI, options)
  .then(() => console.log('✅ Conectado a MongoDB Atlas'))   // Éxito en la conexión
  .catch(err => console.error('❌ Error de conexión:', err)); // Manejo de error
const express = require('express');
const routes = require('./rutas/rutasUsuario');
  const app = express();
  app.use('/api/usuarios', routes);

// Middleware para parsear JSON en las peticiones (body-parser integrado)
app.use(express.json());
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor API escuchando en http://localhost:${PORT}`);
});
const path = require('path');
app.use(express.static(path.join(__dirname, 'public')));