const express = require('express');
const router = express.Router();
const usuarioController = require('../controladores/usuarioControlador');

router.get('', usuarioController.obtenersuarios);
router.get('/:id', usuarioController.obtenerusuarioxid);
router.get('/', usuarioController.crearusuario);
router.get('/:id', usuarioController.actualizarusuarios);
router.get('', usuarioController.eliminarusuarios);
module.exports = router;

